<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class location extends Model
{
    protected $graud = [];
    
    protected $fillabel = ['location', 'family'];
}
