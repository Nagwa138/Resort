<?php 
    $route = 'posts';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">

    <div class="card-header ">
        <h4 class="card-title"><i class="fa fa-table"></i> Table Of Post</h4>
        <p class="card-category">Number Of Posts <?php echo e($posts->total()); ?></p>
    </div>

    <div class="card-body ">
      
      

        <!-- Button trigger modal -->
        <a href="<?php echo e(route($route.'.create')); ?>" class="btn btn-outline-warning">
         <i class="fa fa-plus"></i> Create Post
        </a>
      
      
      <?php if($posts->count() > 0): ?>
       <ul id="success" class="list-unstyled"></ul>
        <table class="table">
            <thead>
             <th>index</th>
             <th>Title</th>
             <th>Photo</th>
             <th>Content</th>
             <th>location</th>
             <th>Action</th>

            </thead>
            <tbody class="cont-data">
             <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <td><?php echo e($index +1); ?></td>

                <td><?php echo e($post->title); ?></td>
                <td><img src='<?php echo e(asset($post->image_path)); ?>' class="photo-user"></td>
                <td><?php echo e($post->content); ?></td>
                
                <td><?php echo e($post->address); ?></td>
                
                

                <td>
                
                  <a class="btn btn-info" href="<?php echo e(route($route. '.edit', [$post->id])); ?>">Edit <i class="fa fa-edit"></i>
                  </a>
                    
                
                  <form action="<?php echo e(route($route. '.destroy', [$post->id])); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('delete')); ?>  
                    <button  type="submit"  class="btn btn-danger">
                      Delete <i class="fa fa-times"></i>
                    </button>
                </form>
                
                   
                
                </td>

              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

            <?php else: ?>
             <h1><i class="fa fa-frown-o"></i> sorry, not_found_data</h1>
            <?php endif; ?>
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TEAM WORK\Resort\resources\views/Dashboard/posts/index.blade.php ENDPATH**/ ?>