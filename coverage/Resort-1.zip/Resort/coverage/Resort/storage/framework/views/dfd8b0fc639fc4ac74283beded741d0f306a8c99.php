<html lang="en">

<head>

    <meta charset="utf-8" >
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo csrf_token(); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>">

    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.ico')); ?>">


    <!--     Fonts and icons     -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">

    <!-- CSS Files -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/light-bootstrap-dashboard.css?v=2.0.0')); ?> " rel="stylesheet" />
    <!-- CSS Just for demo purpose, dont include it in your project -->
    <link href="<?php echo e(asset('css/demo.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/backend.css')); ?>" rel="stylesheet" />
    

</head>

<body>

    
    <div class="wrapper">
        <div class="sidebar" data-image="<?php echo e(asset('img/sidebar-5.jpg')); ?>">

            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item ">
                        <a class="nav-link" href="">
                            <i class="nc-icon nc-chart-pie-35"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    
                         
                    <li class="nav-item <?php echo e(is_active('users')); ?>">
                        <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                            <i class="fa fa-user-cog"></i>
                            <p>Admin</p>
                        </a>
                    </li>
                    
                    <li class="nav-item <?php echo e(is_active('clients')); ?>">
                        <a class="nav-link" href="<?php echo e(route('clients.index')); ?>">
                            <i class="fa fa-users"></i>
                            <p>Client</p>
                        </a>
                    </li>
                    
                    <li class="nav-item <?php echo e(is_active('posts')); ?>">
                        <a class="nav-link" href="<?php echo e(route('posts.index')); ?>">
                            <i class="fa fa-flag"></i>
                            <p>post</p>
                        </a>
                    </li>
                    
                    <li class="nav-item <?php echo e(is_active('likes')); ?>">
                        <a class="nav-link" href="<?php echo e(route('likes.index')); ?>">
                            <i class="fa fa-flag"></i>
                            <p>Review</p>
                        </a>
                    </li>

                    <li class="nav-item <?php echo e(is_active('rents')); ?>">
                        <a class="nav-link" href="<?php echo e(route('rents.show')); ?>">
                            <i class="fa fa-flag"></i>
                            <p>Rent</p>
                        </a>
                    </li>
                    
                    <li class="nav-item <?php echo e(is_active('jobbers')); ?>">
                        <a class="nav-link" href="<?php echo e(route('jobbers.index')); ?>">
                            <i class="fa fa-users"></i>
                            <p>Jobbers</p>
                        </a>
                    </li>
                    
                    <li class="nav-item <?php echo e(is_active('locations')); ?>">
                        <a class="nav-link" href="<?php echo e(route('locations.index')); ?>">
                            <i class="fa fa-map-marked-alt"></i>
                            <p>Locations</p>
                        </a>
                    </li>
                  
                    <li class="nav-item active active-pro">
                        <a class="nav-link active" href="upgrade.html">
                            <i class="nc-icon nc-alien-33"></i>
                            <p>Upgrade to PRO</p>
                        </a>
                    </li>
                </ul>
            </div>


        </div>

        <?php echo $__env->make('Dashboard\Layout\navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('Dashboard\Layout\footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>
<?php /**PATH C:\TEAM WORK\Resort\resources\views/Dashboard\Layout\sidebar.blade.php ENDPATH**/ ?>