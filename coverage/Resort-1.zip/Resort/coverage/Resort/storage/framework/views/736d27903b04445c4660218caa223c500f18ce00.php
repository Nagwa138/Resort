<?php 
    $route = 'posts';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">


<form action="<?php echo e(route($route. '.store')); ?>" method="POST"  enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field("POST")); ?>

  
    <div class="form-group row">
     <div class="col-sm-6 mb-3 mb-sm-0">
        <i class="fa fa-camera photo-camera"></i>
      <input type="file" class="form-control image <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="image" value="<?php echo e(old('image')); ?>"  placeholder="First Name">
      
      <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
       <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
       </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

     </div>

     <div class="col-sm-6">
      <img src="<?php echo e(asset('uploads/users_images/defualt.png')); ?>" class="image-preview" height="80px" width="80px">
     </div>

    </div>

    <div class="form-group row">
     <div class="col-sm-6 mb-3 mb-sm-0">

        <input type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title" value="<?php echo e(old('title')); ?>"  placeholder="title">

        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
         <span class="invalid-feedback" role="alert">
           <strong><?php echo e($message); ?></strong>
         </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

     </div>
    </div>

    <div class="form-group">
     <input type="text" class="form-control <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " name="content" placeholder="content">

       <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>
        <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
        </span>
       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


    </div>


     
     <div class="form-group row">
      <div class="col-md-8">
     
       <select  class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address">
        <option value="">Choose Your Location....</option>
       
       <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($loca->location); ?>"><?php echo e($loca->location); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      
       </select>

      </div>
     </div>
     
    
        <button type="submit" class="btn btn-primary" >Save changes</button>
    
</form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\resources\views/Dashboard/posts/create.blade.php ENDPATH**/ ?>