<?php 
  
  $route = 'admins'

?>  



<?php $__env->startSection('content'); ?>


<div class="card ">


  <form action="<?php echo e(route($route.'.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field("POST")); ?>


    <div class="form-group row">
      <div class="col-sm-6 mb-3 mb-sm-0">
        <i class="fa fa-camera photo-camera"></i>
        <input type="file" class="form-control image <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="image" value="<?php echo e($admin->image); ?>" placeholder="First Name">

        <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
        <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

      </div>

      <div class="col-sm-6">
        <img src="<?php echo e($admin->image); ?>" class="image-preview" height="80px" width="80px">
      </div>

    </div>

    <div class="form-group row">
      <div class="col-sm-6 mb-3 mb-sm-0">

        <input type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e($admin->name); ?>" placeholder="Name">

        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
        <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

      </div>
    </div>

    <div class="form-group">
      <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " name="email" value="<?php echo e($admin->email); ?>" placeholder="Email Address">

      <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
      <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
      </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


    </div>

    
    <div class="form-group">
      <input type="text" class="form-control <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " name="position" value="<?php echo e($admin->position); ?>" placeholder="Position">

      <?php if ($errors->has('position')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('position'); ?>
      <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
      </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


    </div>

    <div class="form-group row">
      <div class="col-sm-6 mb-3 mb-sm-0">
        <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" placeholder="Password">

        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
        <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


      </div>

      <div class="col-md-6">
        <input id="password-confirm" type="password" class="form-control <?php if ($errors->has('password-confirm')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password-confirm'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password_confirmation" placeholder="Repeat Password">

        <?php if ($errors->has('password-confirm')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password-confirm'); ?>
        <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>

    </div>

    <div class="form-group row">
      <div class="nav-tabs-custom">
       <?php
         $moduls = ['admins', 'admins', 'jobbers','posts'];
         $maps   = ['create', 'read', 'update', 'delete'];

       ?>

        <ul class="nav nav-tabs">

         <?php $__currentLoopData = $moduls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="nav-item <?php echo e($index == '0' ? 'active' : ''); ?>">
           <a  href="#<?php echo e($modul); ?>" class="nav-link" data-toggle="tab"><?php echo e($modul); ?></a>
          </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

        <div class="tab-content">
         <?php $__currentLoopData = $moduls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="tab-pane fade show  <?php echo e($index == '0' ? 'active' : ''); ?>" id="<?php echo e($modul); ?>">

           <?php $__currentLoopData = $maps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $map): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <input type="checkbox" name="permissions[]" value="<?php echo e($map . '_' . $modul); ?>">

                   <?php echo e($map); ?>


           <?php echo e($admin->hasPermission($map ."_" . $modul) ? 'checked' : ''); ?>>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
         <!-- /.tab-content -->



      </div>

     </div>
    <button type="submit" class="btn btn-primary">Save changes</button>

  </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\resources\views/Dashboard/admins/edit.blade.php ENDPATH**/ ?>