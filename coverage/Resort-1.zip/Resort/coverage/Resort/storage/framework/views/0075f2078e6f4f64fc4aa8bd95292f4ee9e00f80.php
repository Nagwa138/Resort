<?php 
    $route = 'rents';
      
    $like_count = 0;
    $dislike_count = 0;

?>
 
<?php $__env->startSection('content'); ?>

<div class="card ">
    <div class="card-header ">
        <h4 class="card-title"><i class="fa fa-table"></i> Review your Rents</h4>
        <p class="card-category">Number Of Posts </p>
    </div>
    <div class="card-body ">
      
      

        <!-- Button trigger modal 
        <a href="" class="btn btn-outline-warning">
         <i class="fa fa-plus"></i> Create Post
        </a>
        -->
      
      
      <?php if($posts->count() > 0): ?>
        <div class="container">
          <div class="row">
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
              <div class="post">
                <div class="title">
                  <h2> <?php echo e($post->title); ?></h2>
                  <h4>  <i class="fa fa-clock-o"></i> </h4>
                </div>
                <div class="image-thumnail">
                  <img src="" class="image-thumnail">
                </div>
                <div class="content">
                  <p><?php echo e($post->content); ?></p>
                </div>
              </div>
            </div>  
            <div class="col-md-6">
            <form action="<?php echo e(route('rents.create')); ?>" method="PUT">
                <?php echo e(csrf_field()); ?>

              <input type="hidden" name="client_id" value="1">
              <input type="hidden" name="jobber_id" value="<?php echo e($post->jobber_id); ?>">
              <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
              <input class="btn btn-danger" type="submit" Value="Rent Now !">
              </form>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      <?php else: ?>
        <h1><i class="fa fa-frown-o"></i> sorry, not_found_data</h1>
      <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\coverage\Resort\resources\views/Dashboard/rents/index.blade.php ENDPATH**/ ?>