<?php 
  
  $route = 'admins'

?>  


<?php $__env->startSection('content'); ?>


<div class="card ">

    <div class="card-header ">
        <h4 class="card-title">jobbers</h4>
        <p class="card-category">Number Of Admins <?php echo e($admins->total()); ?></p>
    </div>

    <div class="card-body ">
      
      

        <!-- Button trigger modal -->
        <a href="<?php echo e(route($route.'.create')); ?>" class="btn btn-outline-warning">
         <i class="fa fa-user-plus"></i> Create Admin
        </a>
      
      
      <?php if($admins->count() > 0): ?>
       <ul id="success" class="list-unstyled"></ul>
        <table class="table">
            <thead>
             <th>index</th>
             <th>Name</th>
             <th>Email</th>
             <th>Position</th>
             <th>Image</th>
             

            </thead>
            <tbody class="cont-data">
             <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr id="<?php echo e($admin->id); ?>">
                <td><?php echo e($index +1); ?></td>

                <td><?php echo e($admin->name); ?></td>
                
                <td><?php echo e($admin->email); ?></td>
                
                <td><?php echo e($admin->position); ?></td>
                
                <td><img src='<?php echo e(asset($admin->image_path)); ?>' class="photo-user"></td>
                

                
                <td>
                
                  <a class="btn btn-info" href="<?php echo e(route($route. '.edit', [$admin->id])); ?>">Edit <i class="fa fa-edit"></i>
                  </a>
                    
                  <a href="<?php echo e(route($route. '.destroy', [$admin->id])); ?>" class="btn btn-danger">
                        Delete <i class="fa fa-times"></i>
                  </a>
                
                   
                
                </td>
             

              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

            <?php else: ?>
             <h1><i class="fa fa-frown-o"></i> sorry, not_found_data</h1>
            <?php endif; ?>
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\resources\views/Dashboard/admins/index.blade.php ENDPATH**/ ?>