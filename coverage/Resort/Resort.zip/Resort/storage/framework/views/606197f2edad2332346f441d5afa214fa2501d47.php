<?php 
    $route = 'locations';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">


<form action="<?php echo e(route($route. '.store')); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field("POST")); ?>

  
    

    <div class="form-group row">
     <div class="col-md-5">
       
       <input type="number" class="form-control <?php if ($errors->has('family')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('family'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="family" 
              min="1" length="6" placeholder="Family">

        <?php if ($errors->has('family')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('family'); ?>
         <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
         </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     
     </div>
     

    </div>
     
     <div class="form-group row">
      <div class="col-md-8">
     
       <input  class="form-control <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="location" placeholder="Location">

       <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?>
         <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
        </span>
       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
     </div>
     
    
        <button type="submit" class="btn btn-primary" >Save changes</button>
    
</form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TEAM WORK\Resort\resources\views/Dashboard/location/create.blade.php ENDPATH**/ ?>