<?php 
    $route = 'locations';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">


<form action="<?php echo e(route($route. '.update', [$location->id])); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field("POST")); ?>

  
    

    <div class="form-group row">
     <div class="col-md-5">
       
       <input type="number" class="form-control" value="<?php echo e($location->family); ?>" name="family" 
              min="1" length="6" placeholder="Family">
     
     </div>
     
     <div class=" col-md-6">
     
      <input type="text" class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address" placeholder="address">

      <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
        <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
       </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     </div>

    </div>
     
     <div class="form-group row">
      <div class="col-md-8">
     
       <input  class="form-control " name="location" value="<?php echo e($location->location); ?>" placeholder="Location">

      </div>
     </div>
     
    
        <button type="submit" class="btn btn-primary" >Update changes</button>
    
</form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\resources\views/Dashboard/location/edit.blade.php ENDPATH**/ ?>