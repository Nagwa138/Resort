<?php 
    $route = 'clients';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">

    <div class="card-header ">
        <h4 class="card-title">Table Of Clients</h4>
        <p class="card-category">Number Of Clients <?php echo e($clients->total()); ?></p>
    </div>

    <div class="card-body ">
    
      
      <?php if($clients->count() > 0): ?>
       <ul id="success" class="list-unstyled"></ul>
        <table class="table">
            <thead>
             <th>index</th>
             <th>Email</th>
             <th>Name</th>
             <th>Age</th>
             <th>Job</th>
             <th>Address</th>
             <th>Family</th>
             <th>Action</th>

            </thead>
            <tbody class="cont-data">
             <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr id="<?php echo e($client->id); ?>">
                <td><?php echo e($index +1); ?></td>

                <td><?php echo e($client->email); ?></td>

                <td><?php echo e($client->name); ?></td>
          
                <td><?php echo e($client->age); ?></td>
                
                <td><?php echo e($client->job); ?></td>
                <td><?php echo e($client->address); ?></td>
                
                <td><?php echo e($client->family); ?></td>
                
                
                

                <td>
                
                  <a class="btn btn-info " href="<?php echo e(route($route. '.edit', [$client->id])); ?>">Edit <i class="fa fa-edit"></i>
                  </a>
                    

                  <form action="<?php echo e(route($route. '.destroy', [$client->id])); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('delete')); ?>  
                    <button  type="submit"  class="btn btn-danger">
                      Delete <i class="fa fa-times"></i>
                    </button>
                </form>
                
                   
                
                </td>

              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

            <?php else: ?>
             <h1><i class="fa fa-frown-o"></i> sorry, not_found_data</h1>
            <?php endif; ?>
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\resources\views/Dashboard/clients/index.blade.php ENDPATH**/ ?>