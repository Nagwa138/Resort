<?php 
    $route = 'rents';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">

<form action="<?php echo e(route($route.'.store')); ?>" method="post" enctype="multipart/form-data">
   <?php echo e(csrf_field()); ?>

  <?php echo e(method_field("POST")); ?>

    <div class="form-group row">
     <div class="col-sm-6 mb-3 mb-sm-0">
      <input type="number" class="form-control members <?php if ($errors->has('members')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('members'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="members" value="<?php echo e(old('members')); ?>"  placeholder="Members Count ...">
      
      <?php if ($errors->has('members')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('members'); ?>
       <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
       </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     </div>
    </div>

    <div class="form-group row">
      <div class="col-sm-6 mb-3 mb-sm-0">
    <input  type="date" name="start_at" class="form-control start_at <?php if ($errors->has('start_at')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('start_at'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  value="<?php echo e(old('start_at')); ?>" >
       
       <?php if ($errors->has('start_at')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('start_at'); ?>
        <span class="invalid-feedback" role="alert">
           <strong><?php echo e($message); ?></strong>
        </span>
       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
     </div>
<div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
    <input  type="date" name="end_at" class="form-control end_at <?php if ($errors->has('end_at')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('end_at'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  value="<?php echo e(old('end_at')); ?>" >
       
       <?php if ($errors->has('end_at')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('end_at'); ?>
        <span class="invalid-feedback" role="alert">
           <strong><?php echo e($message); ?></strong>
        </span>
       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
     </div>
    <input type="hidden" name="client_id" value="<?php echo e($client_id); ?>">
    <input type="hidden" name="jobber_id" value="<?php echo e($jobber_id); ?>">
    <input type="hidden" name="post_id" value="<?php echo e($post_id); ?>">
   <button type="submit" class="btn btn-primary" >Save changes</button>
</form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TEAM WORK\Resort\resources\views/dashboard/rents/create.blade.php ENDPATH**/ ?>