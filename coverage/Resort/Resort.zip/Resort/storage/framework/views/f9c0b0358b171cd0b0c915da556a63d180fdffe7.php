<?php 
    $route = 'likes';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">

    <div class="card-header ">
        <h4 class="card-title"><i class="fa fa-table"></i> Table Of Post</h4>
        <p class="card-category">Number Of Posts <?php echo e($likes->total()); ?></p>
    </div>

    <div class="card-body ">
      
      

        <!-- Button trigger modal -->
        <a href="<?php echo e(route($route.'.create')); ?>" class="btn btn-outline-warning">
         <i class="fa fa-plus"></i> Create Post
        </a>
      
      
      <?php if($posts->count() > 0): ?>
        
        <div class="container">
          <div class="row">
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-8">
            <div class="post">
              
              <div class="title">
                 <h2> <?php echo e($post->title); ?></h2>
              </div>
              
              
              <div class="image-thumnail">
                <img src="<?php echo e($post->image_path); ?>" class="image-thumnail">
              </div>
              
              <div class="content">
                <p><?php echo e($post->content); ?></p>
              </div>
              
            </div>
          
          </div>
           <div class="col-md-8">
            <div class="review">
              <button type="button" class="btn btn-default like">
               <span>Like </span> <i class="fa fa-thumbs-up"></i> <b> 10</b>
              </button>  
              
              
              <button type="button" class="btn btn-danger dislike">
                <span>DisLike </span> <i class="fa fa-thumbs-down"></i> <b> 5</b>
               </button>  
            </div>
           </div>  
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </div>
        </div>

      <?php else: ?>
        <h1><i class="fa fa-frown-o"></i> sorry, not_found_data</h1>
      <?php endif; ?>
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\resources\views/Dashboard/comments/index.blade.php ENDPATH**/ ?>