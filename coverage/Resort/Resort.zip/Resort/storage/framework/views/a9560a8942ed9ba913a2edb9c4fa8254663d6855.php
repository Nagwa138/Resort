<?php 
    $route = 'posts';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">

    <div class="card-header ">
        <h4 class="card-title"><i class="fa fa-table"></i>Post</h4>
        
    </div>

    <div class="card-body ">
      <ul class="unlisted-style">
        <li>
          <div class="pull-left">
            <h3> Image :  </h3>
            <img src="<?php echo e($post->image_path); ?>" class="image-circle">
            
          </div>
        
        </li>
        
        <li>
         <h3>Title : </h3>
         <p><?php echo e($post->title); ?></p>
        </li>
        
        
        <li>
          <h3>Content : </h3>
          <p><?php echo e($post->content); ?></p>
        </li>
        
        <li>
          <h3>Location : </h3>
          <p><?php echo e($post->address); ?></p>
        </li>
          
        <li>
          <h3>Status : </h3>
          <p><?php echo e($post->status); ?></p>
         </li>
         
      </ul>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\resources\views/Dashboard/posts/show.blade.php ENDPATH**/ ?>