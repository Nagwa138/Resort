<?php 
    $route = 'posts';
      
    $like_count = 0;
    $dislike_count = 0;
         
         

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">

    <div class="card-header ">
        <h4 class="card-title"><i class="fa fa-table"></i> Table Of Post</h4>
        <p class="card-category">Number Of Posts </p>
    </div>

    <div class="card-body ">
      
      

        <!-- Button trigger modal -->
        <a href="<?php echo e(route($route.'.create')); ?>" class="btn btn-outline-warning">
         <i class="fa fa-plus"></i> Create Post
        </a>
      
      
      <?php if($posts->count() > 0): ?>
        
        <div class="container">
          <div class="row">
          
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6">
          
            <div class="post">
              
              <div class="title">
                 <h2> <?php echo e($post->title); ?></h2>
                 
                 <h4>  <i class="fa fa-clock-o"></i> <?php echo e($post->created_at->diffForHumans()); ?></h4>
              </div>
              
              
              <div class="image-thumnail">
                <img src="<?php echo e($post->image_path); ?>" class="image-thumnail">
              </div>
              
              <div class="content">
                <p><?php echo e($post->content); ?></p>
              </div>
              
            </div>
          
            <div class="form-group row ">
           
             <div class="col-md-2 like">
            
              <h4 class="btn btn-defualt" id="like-<?php echo e($post->id); ?>"  data-id="<?php echo e($post->id); ?>">
                 <i class="fa fa-thumbs-up"></i>
              
              
               <span id="likeCount-<?php echo e($post->id); ?>">
                  <?php echo e($post->likes()->where('post_id', $post->id)->first() ? 
                 
                  $post->likes()->where('like', 1)->count() : '0'); ?>

               
               </span>
              
              </h4>
              
               <form id="addLike" method="POST">
               
                <div class="form-group">
                  <input type="text" name="client_id"  value="<?php echo e(Auth::guard('clients')->user()->name); ?>"   hidden>
              
                  <input type="text" name="post_id" value="<?php echo e($post->id); ?>" hidden >             
                  
                 <button type="submit" class="form-control" id='likeUser-<?php echo e($post->id); ?>' value="0" hidden></button>
                </div>
              
               </form>
              
              
             </div> 
            
             <div class="col-md-2 dislike">
              
               <h4 type="button" class="btn btn-danger dislike" data-id="<?php echo e($post->id); ?>">
                <i class="fa fa-thumbs-down"></i> 
                <span> 
                  <?php echo e($post->likes()->where('post_id', $post->id)->first() ?
                    
                      $post->likes()->where('like', 0)->count() : '0'); ?>

                </span>
               </h4>  
               <form action="" method="POST">
               
                <div class="form-group">
                 <button type="submit" class="form-control" id='dislikeUser-<?php echo e($post->id); ?>' value="0" hidden></button>
                </div>
              
               </form>
             </div>
             
            </div>  
            
           
             <div class="commentstore">
               <form action="<?php echo e(url('likes.store')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('post')); ?>

                 <div class="form-group">
                 <input type="text" name="comment" class="form-control <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Comment Here...">
                 
                 <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?>
                 <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                 </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                 
                  <select  name="client_id" class="form-control" >
                      <option>......</option>
                 <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                 
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </select> 
                 <input type="text" name="post_id" class="form-control" value="<?php echo e($post->id); ?>" hidden>
                  
                 </div>
                 
                 <button type="submit" class="btn btn-primary">
                   <i class="fa fa-send"></i>
                 </button>
               </form>
             </div>
           
             <div id="commentindex">
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <p><?php echo e($comment->comment); ?></p>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
            
            </div> 
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
         
           
          </div>
        </div>

      <?php else: ?>
        <h1><i class="fa fa-frown-o"></i> sorry, not_found_data</h1>
      <?php endif; ?>
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Resort\resources\views/Dashboard/likes/index.blade.php ENDPATH**/ ?>