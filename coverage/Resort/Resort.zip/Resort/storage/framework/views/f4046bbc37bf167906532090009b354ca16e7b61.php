<?php 
    $route = 'jobbers';

?> 

<?php $__env->startSection('content'); ?>


<div class="card ">


<form action="<?php echo e(route($route. '.update', ['id' => $jobber->id])); ?>" method="POST"  enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field("POST")); ?>

  
    <div class="form-group row">
     <div class="col-sm-6 mb-3 mb-sm-0">
        <i class="fa fa-camera photo-camera"></i>
      <input type="file" class="form-control image <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="image">
      
      <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
       <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
       </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

       <img class="photo-camera" src="<?php echo e(asset($jobber->image_path)); ?>">
     </div>

     <div class="col-sm-6">
      <img src="<?php echo e(asset('images/defualt.jpg')); ?>" class="image-preview" height="80px" width="80px">
     </div>

    </div>

    <div class="form-group row">
     <div class="col-sm-6 mb-3 mb-sm-0">

        <input type="text" class="form-control" name="name" value="<?php echo e($jobber->name); ?>"  placeholder="Name">

     </div>
    </div>

    <div class="form-group">
     <input type="email" class="form-control " name="email" value="<?php echo e($jobber->email); ?>" placeholder="Email Address"
     email>

    </div>

    <div class="form-group row">
     <div class="col-sm-6 mb-3 mb-sm-0">
      <input type="password" class="form-control " name="password" placeholder="Password">

      <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
        <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
        </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


    </div>

    <div class="form-group row">
     <div class="col-md-5">
       
       <input type="number" class="form-control " value="<?php echo e($jobber->age); ?>" name="age" 
              min="20" mix="65" placeholder="Age">

        <?php if ($errors->has('age')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('age'); ?>
         <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
         </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     
     </div>
     
     <div class=" col-md-6">
     
      <input type="text" class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address" placeholder="address">

      <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
        <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
       </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
     </div>

    </div>
    
    <div class="form-group row">
     <div class="col-md-12">
     
      <input type="number"  class="form-control" value="<?php echo e($jobber->nationalid); ?>" name="nationalid" 
        min ="14"  placeholder="nationalid" length= "14">

      <?php if ($errors->has('nationalid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nationalid'); ?>
       <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
       </span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    
     </div>
    </div>
    
     
    <div class="form-group row">
     <div class="col-md-8">
     
       <select  class="form-control " name="address">
       <?php $__currentLoopData = $locatoins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($loca->id); ?>" <?php echo e($loca->id == $loca->id ? 'selected' : ''); ?>><?php echo e($loca->location); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
       </select>

     
      </div>
     </div>
     
    
        <button type="submit" class="btn btn-primary" >Save changes</button>
    
</form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard\Layout\sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TEAM WORK\Resort\resources\views/Dashboard/jobbers/edit.blade.php ENDPATH**/ ?>